module.exports = [
    {
        "id": 2,
        "title": "Test Title2 updated",
        "content": "Test Content2 updated",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 2,
        "userId": 1,
        "createdAt": "2024-08-10T08:53:58.000Z",
        "updatedAt": "2024-08-11T12:11:08.000Z",
        "User": {
            "id": 1,
            "name": null,
            "email": null,
            "password": null,
            "createdAt": "2024-08-11T16:53:51.000Z",
            "updatedAt": "2024-08-11T16:53:51.000Z"
        }
    },
    {
        "id": 3,
        "title": "Test Title1",
        "content": "Test Content1",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 2,
        "userId": 1,
        "createdAt": "2024-08-11T06:35:10.000Z",
        "updatedAt": "2024-08-11T06:35:10.000Z",
        "User": {
            "id": 1,
            "name": null,
            "email": null,
            "password": null,
            "createdAt": "2024-08-11T16:53:51.000Z",
            "updatedAt": "2024-08-11T16:53:51.000Z"
        }
    },
    {
        "id": 5,
        "title": "Test Title5",
        "content": "Test Content5",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 2,
        "userId": 1,
        "createdAt": "2024-08-11T08:41:54.000Z",
        "updatedAt": "2024-08-11T08:41:54.000Z",
        "User": {
            "id": 1,
            "name": null,
            "email": null,
            "password": null,
            "createdAt": "2024-08-11T16:53:51.000Z",
            "updatedAt": "2024-08-11T16:53:51.000Z"
        }
    },
    {
        "id": 7,
        "title": "Test Title7",
        "content": "Test Content7",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 2,
        "userId": 1,
        "createdAt": "2024-08-11T12:41:39.000Z",
        "updatedAt": "2024-08-11T12:41:39.000Z",
        "User": {
            "id": 1,
            "name": null,
            "email": null,
            "password": null,
            "createdAt": "2024-08-11T16:53:51.000Z",
            "updatedAt": "2024-08-11T16:53:51.000Z"
        }
    },
    {
        "id": 8,
        "title": "Something",
        "content": "Content 34234324",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 5,
        "userId": 4,
        "createdAt": "2024-08-12T07:01:37.000Z",
        "updatedAt": "2024-08-12T07:01:37.000Z",
        "User": {
            "id": 4,
            "name": "Akshay",
            "email": "Akshay12@gmail.com",
            "password": "$2a$10$znoA8plmbOtQkTPgJ8UNfe2NXo/GlS7rk.1ehH3P7ruJsRqfeFV/m",
            "createdAt": "2024-08-11T17:31:59.000Z",
            "updatedAt": "2024-08-11T17:31:59.000Z"
        }
    },
    {
        "id": 9,
        "title": "Title 1 Something",
        "content": " FJhjdshdsfdlshf  asdfh  Content 34234324",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 5,
        "userId": 4,
        "createdAt": "2024-08-12T07:03:18.000Z",
        "updatedAt": "2024-08-12T07:03:18.000Z",
        "User": {
            "id": 4,
            "name": "Akshay",
            "email": "Akshay12@gmail.com",
            "password": "$2a$10$znoA8plmbOtQkTPgJ8UNfe2NXo/GlS7rk.1ehH3P7ruJsRqfeFV/m",
            "createdAt": "2024-08-11T17:31:59.000Z",
            "updatedAt": "2024-08-11T17:31:59.000Z"
        }
    },
    {
        "id": 10,
        "title": "Title 123 Something",
        "content": " FJhjdshdsfdlshf   232524 asdfh  Content 34234324",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 5,
        "userId": 4,
        "createdAt": "2024-08-12T11:23:35.000Z",
        "updatedAt": "2024-08-12T11:23:35.000Z",
        "User": {
            "id": 4,
            "name": "Akshay",
            "email": "Akshay12@gmail.com",
            "password": "$2a$10$znoA8plmbOtQkTPgJ8UNfe2NXo/GlS7rk.1ehH3P7ruJsRqfeFV/m",
            "createdAt": "2024-08-11T17:31:59.000Z",
            "updatedAt": "2024-08-11T17:31:59.000Z"
        }
    },
    {
        "id": 11,
        "title": "Title 123 Something",
        "content": " FJhjdshdsfdlshf   232524 asdfh  Content 34234324",
        "imageUrl": "http://localhost:3000/uploads/1723436728772.jpg",
        "categoryId": 5,
        "userId": 4,
        "createdAt": "2024-08-12T14:34:24.000Z",
        "updatedAt": "2024-08-12T14:34:24.000Z",
        "User": {
            "id": 4,
            "name": "Akshay",
            "email": "Akshay12@gmail.com",
            "password": "$2a$10$znoA8plmbOtQkTPgJ8UNfe2NXo/GlS7rk.1ehH3P7ruJsRqfeFV/m",
            "createdAt": "2024-08-11T17:31:59.000Z",
            "updatedAt": "2024-08-11T17:31:59.000Z"
        }
    }
]