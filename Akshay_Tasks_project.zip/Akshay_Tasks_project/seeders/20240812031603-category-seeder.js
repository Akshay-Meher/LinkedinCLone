'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
    return await queryInterface.bulkInsert('catergories', [
      {
        name: 'Nodejs',
        createdAt: "2024-08-10 08:53:58",
        updatedAt: "2024-08-10 08:53:58",
      },
      {
        name: "Reactjs",
        createdAt: "2024-08-10 08:53:58",
        updatedAt: "2024-08-10 08:53:58",

      },
      {
        name: "Vuejs",
        createdAt: "2024-08-10 08:53:58",
        updatedAt: "2024-08-10 08:53:58",

      },
      {
        name: "ReactNative",
        createdAt: "2024-08-10 08:53:58",
        updatedAt: "2024-08-10 08:53:58",

      },
      {
        name: "Reactjs",
        createdAt: "2024-08-10 08:53:58",
        updatedAt: "2024-08-10 08:53:58",

      },
      {
        name: "Reactjs",
        createdAt: "2024-08-10 08:53:58",
        updatedAt: "2024-08-10 08:53:58",

      },
    ], {});
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    return await queryInterface.bulkDelete('catergories', null, {});
  }
};
