const { transporter } = require('../email/sendEmail');
const { Comment } = require('../models');

const commentsController = async (req, res) => {
    console.log("Comments useraData ", req.userData);
    console.log("Comments email ", req.params.email);
    // console.log("Comments text", req.body.commentText);

    try {
        const comment = await Comment.create({
            userId: req.userData.id,
            postId: req.params.postId,
            content: req.body.commentText
        });
        if (comment) {


            const mailOptions = {
                to: req.params.email,
                from: 'passwordreset@demo.com',
                subject: 'New Comment on Your Post!',
                html: `
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>New Comment Notification</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            margin: 0;
                            padding: 0;
                        }
                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            background-color: #ffffff;
                            padding: 20px;
                            border-radius: 8px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        }
                        .header {
                            background-color: #007bff;
                            color: #ffffff;
                            padding: 10px;
                            border-radius: 8px 8px 0 0;
                            text-align: center;
                        }
                        .content {
                            margin: 20px 0;
                        }
                        .footer {
                            font-size: 12px;
                            color: #777777;
                            text-align: center;
                            margin-top: 20px;
                        }
                        a {
                            color: #007bff;
                            text-decoration: none;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>New Comment on Your Post!</h1>
                        </div>
                        <div class="content">
                            <p>Hello,</p>
                            <p><strong>${req.userData?.name}</strong> commented on your post. Here are the details:</p>
                            <p><strong>Post Link:</strong> <a href="{{postLink}}">{{postLink}}</a></p>
                            <p><strong>Comment:</strong> {{comment}}</p>
                        </div>
                        <div class="footer">
                            <p>Best regards,<br>Your Team</p>
                        </div>
                    </div>
                </body>
                </html>
            `
            };


            transporter.sendMail(mailOptions, (err) => {
                if (err) {
                    return res.status(500).json({ message: 'Error sending the email' });
                }
            });

            return res.redirect("/post");

        } else {
            res.redirect("post/add-post");
        }
    } catch (error) {
        console.log("Error", error);
        res.status(404).json({
            error: error
        });
    }



}


module.exports = commentsController;